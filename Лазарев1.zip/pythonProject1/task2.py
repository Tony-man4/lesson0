#2nd program
print(9.99>9.98 and 1000!=1000.1)