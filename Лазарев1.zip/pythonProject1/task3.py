#3rd program
print(2*2+2)
print(2*(2+2))
print(bool((2*2+2)==(2*(2+2))))