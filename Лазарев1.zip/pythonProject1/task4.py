#4rd program
print (str(int((float(123.456*10)))%10))
